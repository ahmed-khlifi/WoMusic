import React from 'react'

function Footer() {
    return (
        <footer>
            elaborer par Hammadi Mezzien et Abdesslem M'saad
        </footer>
    )
}

export default Footer